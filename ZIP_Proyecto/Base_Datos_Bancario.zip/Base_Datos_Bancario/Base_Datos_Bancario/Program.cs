﻿using SistemaBancario.Menus;
 
namespace SistemaBancario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            MenuLogin.Mostrar();
        }
    }
}
 