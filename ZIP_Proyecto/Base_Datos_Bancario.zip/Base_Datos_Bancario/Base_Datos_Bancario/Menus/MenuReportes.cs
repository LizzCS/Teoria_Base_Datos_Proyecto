using SistemaBancario.Repositories;
using SistemaBancario.Models;
using SistemaBancario;

namespace SistemaBancario.Menus
{
    public class MenuReportes
    {
        public static async Task Mostrar()
        {
            bool continuar = true;
            while (continuar)
            {
                Console.Clear();
                UI.Titulo("REPORTES");
                Console.WriteLine();
                Console.WriteLine("  1. Resumen Mensual (Ingresos vs Gastos vs Ahorros)");
                Console.WriteLine("  2. Distribución de Gastos por Categoría");
                Console.WriteLine("  3. Cumplimiento de Presupuesto");
                Console.WriteLine("  4. Tendencia de Gastos por Categoría");
                Console.WriteLine("  5. Estado de Obligaciones Fijas");
                Console.WriteLine("  6. Progreso de Ahorros");
                Console.WriteLine("  7. Generar TODOS (mes actual)");
                Console.WriteLine("  0. Volver");

                int op = UI.LeerOpcion(7);

                if (op == 0) { continuar = false; continue; }

                try
                {
                    switch (op)
                    {
                        case 1: await Reporte1();     break;
                        case 2: await Reporte2();     break;
                        case 3: await Reporte3();     break;
                        case 4: await Reporte4();     break;
                        case 5: await Reporte5();     break;
                        case 6: await Reporte6();     break;
                        case 7: await GenerarTodos(); break;
                    }
                }
                catch (Exception ex) { UI.Error(ex.Message); UI.Pausa(); }
            }
        }

        // ── Helpers ───────────────────────────────────────────────
        private static (int anio, int mes) PedirPeriodo()
        {
            int anio = DateTime.Now.Year;
            int mes  = DateTime.Now.Month;
            string anioStr = UI.Leer($"Año (Enter = {anio})");
            string mesStr  = UI.Leer($"Mes (Enter = {mes})");
            if (!string.IsNullOrEmpty(anioStr)) int.TryParse(anioStr, out anio);
            if (!string.IsNullOrEmpty(mesStr))  int.TryParse(mesStr,  out mes);
            return (anio, mes);
        }

        private static int? PedirPresupuesto()
        {
            var presupuestos = PresupuestoRepo.Listar();
            if (presupuestos.Count == 0) { UI.Error("No tienes presupuestos."); return null; }

            var activo = presupuestos.FirstOrDefault(p => p.EstadoPresupuesto == 1);

            UI.Separador();
            Console.WriteLine($"  {"ID",-5}  {"Nombre",-30}  {"Estado"}");
            UI.Separador();
            foreach (var p in presupuestos)
            {
                string estado = p.EstadoPresupuesto == 1 ? "Activo" : p.EstadoPresupuesto == 2 ? "Cerrado" : "Borrador";
                Console.WriteLine($"  {p.IdPresupuesto,-5}  {p.NombreDescriptivo,-30}  {estado}");
            }
            UI.Separador();

            string idStr = UI.Leer($"ID Presupuesto (Enter = {activo?.IdPresupuesto ?? presupuestos[0].IdPresupuesto})");
            if (string.IsNullOrEmpty(idStr))
                return activo?.IdPresupuesto ?? presupuestos[0].IdPresupuesto;

            return int.TryParse(idStr, out int id) ? id : activo?.IdPresupuesto;
        }

        // ── Reporte 1 ─────────────────────────────────────────────
        private static async Task Reporte1()
        {
            Console.Clear();
            UI.Titulo("REPORTE 1 — RESUMEN MENSUAL");
            Console.WriteLine("  Filtros (Enter para usar el mes actual):");

            int? idP = PedirPresupuesto();
            if (idP == null) { UI.Pausa(); return; }

            var (anio, mes) = PedirPeriodo();

            try
            {
                UI.Info($"Generando reporte para {mes}/{anio}...");
                Graficos.Reporte1(idP.Value, anio, mes).GetAwaiter().GetResult();
            }
            catch (Exception ex) { UI.Error(ex.Message); }
            finally { UI.Pausa(); } 
        }

        // ── Reporte 2 ─────────────────────────────────────────────
        private static async Task Reporte2()
        {
            Console.Clear();
            UI.Titulo("REPORTE 2 — DISTRIBUCIÓN DE GASTOS");
            Console.WriteLine("  Filtros (Enter para usar el mes actual):");

            var (anio, mes) = PedirPeriodo();

            try
            {
                UI.Info($"Generando reporte para {mes}/{anio}...");
                Graficos.Reporte2(anio, mes).GetAwaiter().GetResult();
            }
            catch (Exception ex) { UI.Error(ex.Message); }
            finally { UI.Pausa(); } 
        }

        // ── Reporte 3 ─────────────────────────────────────────────
        private static async Task Reporte3()
        {
            Console.Clear();
            UI.Titulo("REPORTE 3 — CUMPLIMIENTO DE PRESUPUESTO");
            Console.WriteLine("  Filtros (Enter para usar el mes actual):");

            int? idP = PedirPresupuesto();
            if (idP == null) { UI.Pausa(); return; }

            var (anio, mes) = PedirPeriodo();

            try
            {
                UI.Info($"Generando reporte para {mes}/{anio}...");
                Graficos.Reporte3(idP.Value, anio, mes).GetAwaiter().GetResult();
            }
            catch (Exception ex) { UI.Error(ex.Message); }
            finally { UI.Pausa(); } 
        }

        // ── Reporte 4 ─────────────────────────────────────────────
        private static async Task Reporte4()
        {
            Console.Clear();
            UI.Titulo("REPORTE 4 — TENDENCIA DE GASTOS");
            Console.WriteLine("  Rango de fechas:");

            var presupuestos = PresupuestoRepo.Listar();
            var activo       = presupuestos.FirstOrDefault(p => p.EstadoPresupuesto == 1);

            int anioDesde = activo?.AnioInicio ?? DateTime.Now.Year;
            int mesDesde  = activo?.MesInicio  ?? 1;
            int anioHasta = DateTime.Now.Year;
            int mesHasta  = DateTime.Now.Month;

            string aD = UI.Leer($"Año desde  (Enter = {anioDesde})");
            string mD = UI.Leer($"Mes desde  (Enter = {mesDesde})");
            string aH = UI.Leer($"Año hasta  (Enter = {anioHasta})");
            string mH = UI.Leer($"Mes hasta  (Enter = {mesHasta})");

            if (!string.IsNullOrEmpty(aD)) int.TryParse(aD, out anioDesde);
            if (!string.IsNullOrEmpty(mD)) int.TryParse(mD, out mesDesde);
            if (!string.IsNullOrEmpty(aH)) int.TryParse(aH, out anioHasta);
            if (!string.IsNullOrEmpty(mH)) int.TryParse(mH, out mesHasta);

            try
            {
                UI.Info($"Generando reporte {mesDesde}/{anioDesde} — {mesHasta}/{anioHasta}...");
                Graficos.Reporte4(anioDesde, mesDesde, anioHasta, mesHasta).GetAwaiter().GetResult();
            }
            catch (Exception ex) { UI.Error(ex.Message); }
            finally { UI.Pausa(); } 
        }

        // ── Reporte 5 ─────────────────────────────────────────────
        private static async Task Reporte5()
        {
            Console.Clear();
            UI.Titulo("REPORTE 5 — ESTADO DE OBLIGACIONES");
            Console.WriteLine("  Filtros (Enter para usar el mes actual):");

            var (anio, mes) = PedirPeriodo();

            try
            {
                UI.Info($"Generando reporte para {mes}/{anio}...");
                Graficos.Reporte5(anio, mes).GetAwaiter().GetResult();
            }
            catch (Exception ex) { UI.Error(ex.Message); }
            finally { UI.Pausa(); } 
            
        }

        // ── Reporte 6 ─────────────────────────────────────────────
        private static async Task Reporte6()
        {
            Console.Clear();
            UI.Titulo("REPORTE 6 — PROGRESO DE AHORROS");
            Console.WriteLine("  Filtros (Enter para usar el mes actual):");

            int? idP = PedirPresupuesto();
            if (idP == null) { UI.Pausa(); return; }

            var (anio, mes) = PedirPeriodo();

            try
            {
                UI.Info($"Generando reporte para {mes}/{anio}...");
                Graficos.Reporte6(idP.Value, anio, mes).GetAwaiter().GetResult();
            }
            catch (Exception ex) { UI.Error(ex.Message); }
            finally 
            { 
                Console.WriteLine("DEBUG: antes de pausa");
                Console.ReadKey(true);
                Console.WriteLine("DEBUG: despues de pausa");
            }        
    }

        // ── Generar Todos ─────────────────────────────────────────
        private static async Task GenerarTodos()
        {
            Console.Clear();
            UI.Titulo("GENERAR TODOS LOS REPORTES");

            var presupuestos = PresupuestoRepo.Listar();
            var activo       = presupuestos.FirstOrDefault(p => p.EstadoPresupuesto == 1);

            if (activo == null)
            {
                UI.Error("No tienes un presupuesto activo.");
                UI.Pausa();
                return;
            }

            Console.WriteLine($"  Presupuesto : {activo.NombreDescriptivo}");
            Console.WriteLine($"  Periodo     : {DateTime.Now.Month}/{DateTime.Now.Year}");
            Console.WriteLine();

            try
            {
                await Graficos.GenerarTodos();
            }
            catch (Exception ex) { UI.Error(ex.Message); }
            finally { UI.Pausa(); } 
        }
    }
}